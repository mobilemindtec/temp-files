-module(controller_example_2).

-include_lib("controller_html_helper.hrl").

html(Context) ->
    {<<"<h1>Hello 2</h1>">>, Context}.