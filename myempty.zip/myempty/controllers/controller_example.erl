-module(controller_example).

-include_lib("controller_html_helper.hrl").

html(Context) ->
    {<<"<h1>Hello</h1>">>, Context}.
