-module(service_play_ping).
-author("Arjan Scherpenisse <arjan@scherpenisse.net>").

-svc_title("Retrieve uptime statistics of the system.").
-svc_needauth(false).

-export([process_get/1]).

-include_lib("zotonic.hrl").

process_get(_Context) ->
    Stats = [{count, 12310}, {uptime, 399}],
    z_convert:to_json(Stats).