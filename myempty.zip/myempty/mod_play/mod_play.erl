-module(mod_play).

-author("Arjan Scherpenisse <arjan@scherpenisse.net>").

-svc_title("Retrieve uptime statistics of the system.").


-include_lib("zotonic.hrl").
